import express from "express";
import Group from "../models/Group.js";
import GroupExpense from "../models/GroupExpense.js";
import { verifyToken } from "../middleware/auth.js";

const router = express.Router();

// ✅ Create a new group
router.post("/", verifyToken, async (req, res) => {
  try {
    const { name, members } = req.body;

    if (!name) return res.status(400).json({ message: "Group name is required" });

    // Add creator's email to members
    const newGroup = new Group({
      name,
      members: [...(members || []), req.user.email],
      createdBy: req.user.id,
    });

    await newGroup.save();
    res.status(201).json(newGroup);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// ✅ Get all groups
router.get("/", verifyToken, async (req, res) => {
  try {
    const groups = await Group.find({});
    res.json(groups);
  } catch (err) {
    res.status(500).json({ message: "Error fetching groups", error: err.message });
  }
});

// ✅ Get single group with members
router.get("/:id", verifyToken, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ message: "Group not found" });

    res.json(group);
  } catch (err) {
    res.status(500).json({ message: "Error fetching group", error: err.message });
  }
});

// ✅ Delete group (only creator)
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ message: "Group not found" });

    if (group.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to delete this group" });
    }

    await Group.findByIdAndDelete(req.params.id);
    res.json({ message: "Group deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting group", error: err.message });
  }
});

// ✅ Add expense to group
router.post("/:id/expenses", verifyToken, async (req, res) => {
  try {
    const { description, amount, paidBy, splitType, splitDetails } = req.body;
    const groupId = req.params.id;

    const group = await Group.findById(groupId);
    if (!group) return res.status(404).json({ message: "Group not found" });

    if (!description || !amount || !paidBy) {
      return res.status(400).json({ message: "Description, amount, and paidBy are required" });
    }

    const expense = new GroupExpense({
      groupId,
      description,
      amount,
      paidBy,
      splitType,
      splitDetails,
    });

    await expense.save();

    // calculate balances excluding logged-in user
    const expenses = await GroupExpense.find({ groupId });
    const balances = {};
    group.members.forEach(member => {
      if (member !== req.user.email) balances[member] = 0;
    });

    expenses.forEach(exp => {
      const payerEmail = exp.paidBy.toString();

      if (exp.splitType === "equal") {
        const share = exp.amount / group.members.length;
        group.members.forEach(member => {
          if (member === req.user.email) return; // skip logged-in user
          if (member === payerEmail) {
            balances[member] += exp.amount - share;
          } else {
            balances[member] -= share;
          }
        });
      } else {
        for (const [member, percent] of Object.entries(exp.splitDetails)) {
          if (member === req.user.email) continue; // skip logged-in user
          const share = (exp.amount * percent) / 100;
          if (member === payerEmail) {
            balances[member] += exp.amount - share;
          } else {
            balances[member] -= share;
          }
        }
      }
    });

    res.status(201).json({ expense, balances });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error creating expense", error: err.message });
  }
});

// ✅ Get all expenses of a group with balances
router.get("/:id/expenses", verifyToken, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ message: "Group not found" });

    const expenses = await GroupExpense.find({ groupId: group._id });

    // calculate balances excluding logged-in user
    const balances = {};
    group.members.forEach(member => {
      if (member !== req.user.email) balances[member] = 0;
    });

    expenses.forEach(exp => {
      const payerEmail = exp.paidBy.toString();

      if (exp.splitType === "equal") {
        const share = exp.amount / group.members.length;
        group.members.forEach(member => {
          if (member === req.user.email) return; // skip logged-in user
          if (member === payerEmail) {
            balances[member] += exp.amount - share;
          } else {
            balances[member] -= share;
          }
        });
      } else {
        for (const [member, percent] of Object.entries(exp.splitDetails)) {
          if (member === req.user.email) continue; // skip logged-in user
          const share = (exp.amount * percent) / 100;
          if (member === payerEmail) {
            balances[member] += exp.amount - share;
          } else {
            balances[member] -= share;
          }
        }
      }
    });

    res.json({ expenses, balances });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching expenses", error: err.message });
  }
});

export default router;
