// routes/groupExpense.js
import express from "express";
import mongoose from "mongoose";
import GroupExpense from "../models/GroupExpense.js";
import Group from "../models/Group.js";
import { verifyToken } from "../middleware/auth.js";

const router = express.Router();

// Helper: calculate balances per user
const calculateBalances = (group, expenses) => {
  const balances = {};

  // Initialize all members
  group.members.forEach(email => {
    balances[email] = 0;
  });

  expenses.forEach(exp => {
    const payerEmail = exp.paidBy; // always store as email
    const members = Object.keys(exp.splitDetails);

    members.forEach(memberEmail => {
      const share = exp.splitDetails[memberEmail];
      if (memberEmail === payerEmail) return; // skip self
      balances[memberEmail] -= share;      // member owes
      balances[payerEmail] += share;       // payer gets
    });
  });

  return balances;
};

// GET all expenses + balances for a group
router.get("/group/:groupId", verifyToken, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Group not found" });

    const expenses = await GroupExpense.find({ groupId: group._id }).lean();

    const balances = calculateBalances(group, expenses);

    res.json({ expenses, balances });
  } catch (err) {
    console.error("GET /group-expenses error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// POST: add a new expense
router.post("/group/:groupId", verifyToken, async (req, res) => {
  const { description, amount, splitType, splitDetails, paidBy } = req.body;

  if (!description || !amount || !paidBy) {
    return res.status(400).json({ message: "Required fields missing" });
  }

  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Group not found" });

    const expenseMembers = group.members; // emails
    let finalSplit = {};

    if (splitType === "equal") {
      const share = Number(amount) / expenseMembers.length;
      expenseMembers.forEach(email => {
        finalSplit[email] = share;
      });
    } else if (splitType === "percentage") {
      Object.entries(splitDetails).forEach(([email, pct]) => {
        if (expenseMembers.includes(email)) {
          finalSplit[email] = (pct / 100) * Number(amount);
        }
      });
      if (!finalSplit[paidBy]) finalSplit[paidBy] = 0; // make sure paidBy included
    }

    const expense = new GroupExpense({
      description,
      amount: Number(amount),
      paidBy,           // email
      groupId: group._id,
      splitType,
      splitDetails: finalSplit,
    });

    await expense.save();

    const expenses = await GroupExpense.find({ groupId: group._id }).lean();
    const balances = calculateBalances(group, expenses);

    res.status(201).json({ expense, balances });
  } catch (err) {
    console.error("POST /group-expenses error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
