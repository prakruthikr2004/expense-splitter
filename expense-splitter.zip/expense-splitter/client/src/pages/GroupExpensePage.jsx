import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function GroupExpensePage() {
  const { id: groupId } = useParams();
  const [group, setGroup] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [balances, setBalances] = useState({});
  const [form, setForm] = useState({
    description: "",
    amount: "",
    splitType: "equal",
    splitDetails: {}
  });

  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    const fetchGroupAndExpenses = async () => {
      try {
        const resGroup = await fetch(`http://localhost:5000/groups/${groupId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const groupData = await resGroup.json();
        setGroup(groupData);

        const resExpenses = await fetch(`http://localhost:5000/api/group-expenses/group/${groupId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await resExpenses.json();
        setExpenses(data.expenses || []);
        setBalances(data.balances || {});
      } catch (err) {
        console.error(err);
      }
    };
    fetchGroupAndExpenses();
  }, [groupId]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSplitChange = (memberId, value) => {
    setForm(prev => ({ ...prev, splitDetails: { ...prev.splitDetails, [memberId]: Number(value) } }));
  };

  const handleAddExpense = async () => {
  try {
    // ensure paidBy is included
    const payload = {
      ...form,
      amount: Number(form.amount),
      paidBy: user?.id,
      splitDetails: { ...form.splitDetails, [user?.id]: form.splitDetails[user?.id] || 0 }
    };

    const res = await fetch(`http://localhost:5000/api/group-expenses/group/${groupId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (res.ok) {
      setExpenses([...expenses, data.expense]);
      setBalances(data.balances);
      setForm({ description: "", amount: "", splitType: "equal", splitDetails: {} });
    } else {
      alert(data.message || "Error adding expense");
    }
  } catch (err) {
    console.error(err);
  }
};


  const handleDeleteExpense = async (expenseId) => {
    try {
      const res = await fetch(`http://localhost:5000/api/group-expenses/${expenseId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setExpenses(expenses.filter(e => e._id !== expenseId));
        setBalances(data.balances);
      } else {
        alert(data.message || "Error deleting expense");
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!group) return <div className="text-center mt-10">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6">
      <h2 className="text-2xl font-bold text-center">{group.name} - Expenses</h2>

      {/* Add Expense Form */}
      <div className="bg-white shadow-md rounded p-4 space-y-4">
        <input
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Description"
          className="w-full border px-3 py-2 rounded"
        />
        <input
          type="number"
          name="amount"
          value={form.amount}
          onChange={handleChange}
          placeholder="Amount"
          className="w-full border px-3 py-2 rounded"
        />
        <select
          name="splitType"
          value={form.splitType}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="equal">Equal</option>
          <option value="percentage">Percentage</option>
        </select>

        {form.splitType === "percentage" && group.members.map(m => (
          <div key={m._id || m} className="flex items-center space-x-2">
            <label className="w-24">{m.name || m}</label>
            <input
              type="number"
              value={form.splitDetails[m._id || m] || 0}
              onChange={e => handleSplitChange(m._id || m, e.target.value)}
              className="border px-2 py-1 rounded w-20"
            />%
          </div>
        ))}

        <button
          onClick={handleAddExpense}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Add Expense
        </button>
      </div>

      {/* Expenses List */}
      <div className="bg-white shadow-md rounded p-4">
        <h3 className="text-xl font-semibold mb-2">Expenses</h3>
        <ul className="space-y-1">
          {expenses.map(exp => (
            <li key={exp._id} className="flex justify-between border-b py-1 items-center">
              <span>
                <span className="font-medium">{exp.description}</span> - ₹{exp.amount} (Paid by {exp.paidBy?.name || exp.paidBy})
              </span>
              <button
                onClick={() => handleDeleteExpense(exp._id)}
                className="text-red-500 hover:underline"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Balances */}
      {/* Balances */}
<div className="bg-white shadow-md rounded p-4 mt-4">
  <h3 className="text-xl font-semibold mb-2">Balances</h3>
  <ul className="space-y-1">
    {group.members
      .filter(m => (m._id || m) !== user.id) // Exclude self
      .map(m => {
        const memberId = m._id || m;
        const name = m.name || m;
        // Correct balance relative to current user
        const amt = (balances[user.id] || 0) - (balances[memberId] || 0);
        // Exclude if balance is 0 (no debt)
        if (amt === 0) return null;

        return (
          <li key={memberId} className="flex justify-between">
            <span>{name}</span>
            <span className={amt < 0 ? "text-red-500" : "text-green-500"}>
              {amt < 0
                ? `You owe ₹${Math.abs(amt).toFixed(2)}`
                : `owes you ₹${amt.toFixed(2)}`}
            </span>
          </li>
        );
      })
      .filter(Boolean) // Remove nulls from zero balances
    }
  </ul>
</div>

    </div>
  );
}
