import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import GroupForm from "../components/GroupForm";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Groups() {
  const [groups, setGroups] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));
  const navigate = useNavigate();

  const fetchGroups = async () => {
    try {
      const res = await fetch("http://localhost:5000/groups", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch groups");
      const data = await res.json();

      const groupsWithBalances = await Promise.all(
        data.map(async (group) => {
          const resBal = await fetch(
            `http://localhost:5000/api/group-expenses/group/${group._id}`,
            { headers: { Authorization: `Bearer ${token}` } }
          );
          const balData = await resBal.json();
          const balances = balData.balances || {};

          const userBalance = {};
          group.members.forEach((m) => {
            const memberId = typeof m === "string" ? m : m._id;
            const memberName = typeof m === "string" ? m : m.name || m.email;
            if (memberId !== user.id) {
              // FIXED: Reverse order so positive = they owe you
              const amt = (balances[user.id] || 0) - (balances[memberId] || 0);
              userBalance[memberName] = amt;
            }
          });

          return { ...group, userBalance };
        })
      );

      setGroups(groupsWithBalances);
    } catch (err) {
      toast.error("Error fetching groups: " + err.message);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, []);

  const handleGroupCreated = (newGroup) => {
    setGroups((prev) => [...prev, newGroup]);
    setShowForm(false);
    toast.success("Group created successfully!");
  };

  const handleDeleteGroup = async (groupId) => {
    if (!window.confirm("Are you sure you want to delete this group?")) return;
    try {
      const res = await fetch(`http://localhost:5000/groups/${groupId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      setGroups((prev) => prev.filter((g) => g._id !== groupId));
      toast.success("Group deleted successfully!");
    } catch (err) {
      toast.error("Failed to delete group: " + err.message);
    }
  };

  return (
    <div className="p-6">
      <ToastContainer position="top-right" autoClose={3000} />
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Your Groups</h2>
        <button
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition"
        >
          + Create Group
        </button>
      </div>

      <div className="space-y-4">
        {groups.length > 0 ? (
          groups.map((group) => (
            <div
              key={group._id}
              className="border p-4 rounded-lg bg-white shadow hover:shadow-md transition cursor-pointer"
              onClick={() =>
                navigate(`/dashboard/groups/${group._id}/expenses`)
              }
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold mb-1">{group.name}</h3>
                  <p className="mb-2 text-sm text-gray-700">
                    Members:{" "}
                    {group.members && group.members.length > 0
                      ? group.members
                          .map((m) => (typeof m === "string" ? m : m.email))
                          .join(", ")
                      : "No members"}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteGroup(group._id);
                  }}
                  className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition"
                >
                  Delete
                </button>
              </div>

              {group.userBalance && Object.keys(group.userBalance).length > 0 && (
                <div className="bg-gray-50 p-2 rounded mt-2">
                  <h4 className="font-semibold mb-1">Balances:</h4>
                  <ul>
                    {Object.entries(group.userBalance).map(([member, amt]) => (
                      <li
                        key={member}
                        className="flex justify-between text-sm"
                      >
                        <span>{member}</span>
                        <span
                          className={amt < 0 ? "text-red-500" : "text-green-500"}
                        >
                          {amt < 0
                            ? `You owe ₹${Math.abs(amt).toFixed(2)}`
                            : `Owes you ₹${amt.toFixed(2)}`}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))
        ) : (
          <p className="text-gray-600">No groups yet.</p>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 className="text-lg font-bold mb-4">Create Group</h3>
            <GroupForm onGroupCreated={handleGroupCreated} />
            <button
              onClick={() => setShowForm(false)}
              className="mt-4 px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
