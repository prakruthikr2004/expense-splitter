import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Profile() {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("user")) || {}
  );
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState(user.name || "");
  const navigate = useNavigate();

  // ✅ Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

const handleUpdate = async () => {
  if (!newName.trim()) {
    toast.error("Name cannot be empty!");
    return;
  }

  try {
    const token = localStorage.getItem("token");
   const res = await fetch("http://localhost:5000/auth/update-name", {
  method: "PUT",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  },
  body: JSON.stringify({ name: newName }),
});


    const data = await res.json();

    if (res.ok) {
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      setUser(data.user);
      setIsEditing(false);
    } else {
      toast.error(data.message);
    }
  } catch (err) {
    console.error("Update failed:", err);
    toast.error("Update failed!");
  }
};




  return (
    
    <div className="flex items-center justify-center h-screen bg-gray-100">
        <ToastContainer position="top-right" autoClose={3000} />
      <div className="w-96 h-auto p-6 bg-white shadow-lg rounded-lg flex flex-col items-center justify-center text-center">
        <h2 className="text-xl font-bold mb-4">Profile Details</h2>

        <img
          src={
            user?.avatar && user.avatar.startsWith("http")
              ? user.avatar
              : "https://i.pravatar.cc/150"
          }
          alt="Profile"
          className="w-24 h-24 rounded-full border mb-4"
        />

        {isEditing ? (
          <div className="space-y-4">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="border px-3 py-2 rounded-md w-full"
            />
        <div className="space-x-3"> 
            <button
              onClick={handleUpdate}
              className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 "
            >
              Save
            </button>  
            <button
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400"
            >
              Cancel
            </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p>
              <b>Name:</b> {user.name}
            </p>
            <p>
              <b>Email:</b> {user.email}
            </p>
          </div>
        )}

        {!isEditing && (
          <div className="mt-6 flex space-x-3">
            <button
              onClick={() => {
                setNewName(user.name); // ✅ reset input when entering edit mode
                setIsEditing(true);
              }}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Edit Name
            </button>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
