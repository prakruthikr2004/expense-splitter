import { useState } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";

export default function DashboardLayout() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
    setIsOpen(false); // close after logout
  };

  const closeMenu = () => setIsOpen(false);

  return (
    <div className="flex h-screen">
      {/* Sidebar (hidden until toggled) */}
      {isOpen && (
        <div
          className="fixed inset-y-0 left-0 w-64 bg-gray-800 text-white shadow-lg z-50
          transform transition-transform duration-300 ease-in-out"
        >
          <div className="p-4 flex justify-between items-center">
            <h2 className="text-xl font-bold">Dashboard</h2>
            <button onClick={() => setIsOpen(false)}>
              <X size={24} />
            </button>
          </div>

          <nav className="mt-6 space-y-4 px-4">
            <Link to="home" onClick={closeMenu} className="block hover:text-gray-300">Home</Link>
            <Link to="profile" onClick={closeMenu} className="block hover:text-gray-300">
              Profile
            </Link>
            <Link to="expenses" onClick={closeMenu} className="block hover:text-gray-300">
              Expenses
            </Link>
            <Link to="groups" onClick={closeMenu} className="block hover:text-gray-300">
              Groups
            </Link>
            <button
              onClick={handleLogout}
              className="block text-left w-full hover:text-gray-300"
            >
              Logout
            </button>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 p-6">
        {/* Hamburger Menu Button (always visible) */}
        <button
          className="mb-4"
          onClick={() => setIsOpen(true)}
        >
          <Menu size={28} />
        </button>

        <Outlet />
      </div>
    </div>
  );
}
