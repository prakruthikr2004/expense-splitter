import { useContext, useState } from "react";
import { ExpensesContext } from "../context/ExpensesContext";

export default function Expenses() {
  const { expenses, addExpense, deleteExpense } = useContext(ExpensesContext);

  const [type, setType] = useState("Expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [note, setNote] = useState("");

  const handleAdd = (e) => {
    e.preventDefault();
    if (!amount || !category) return;

    addExpense({ type, amount: Number(amount), category, note });
    setAmount("");
    setCategory("");
    setNote("");
  };

  const balance = expenses.reduce(
    (acc, e) => (e.type === "Income" ? acc + e.amount : acc - e.amount),
    0
  );

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4 text-center">💰 Expense Tracker</h2>

      <div className="bg-gray-100 p-4 rounded-lg shadow mb-6 text-center">
        <h3 className="text-xl font-semibold">Balance: ₹{balance}</h3>
      </div>

      <form onSubmit={handleAdd} className="mb-6 flex flex-col gap-3 bg-white p-4 rounded-lg shadow">
        <select value={type} onChange={(e) => setType(e.target.value)} className="border p-2 rounded">
          <option>Expense</option>
          <option>Income</option>
        </select>
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="border p-2 rounded"
        />
        <input
          type="text"
          placeholder="Category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="border p-2 rounded"
        />
        <input
          type="text"
          placeholder="Note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          className="border p-2 rounded"
        />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          ➕ Add {type}
        </button>
      </form>

      <ul className="space-y-3">
        {expenses.map((e) => (
          <li key={e._id} className="flex justify-between items-center bg-white p-3 rounded shadow">
            <div>
              <p className="font-bold">{e.type}: ₹{e.amount}</p>
              <p className="text-sm text-gray-600">{e.category} {e.note && `- ${e.note}`}</p>
            </div>
            <button onClick={() => deleteExpense(e._id)} className="text-red-500 hover:text-red-700">❌</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
