import { useContext, useEffect, useState } from "react";
import { ExpensesContext } from "../context/ExpensesContext";

export default function Home() {
  const { expenses } = useContext(ExpensesContext);
  const [groups, setGroups] = useState([]);
  const [balances, setBalances] = useState({}); // store balances per group
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  const fetchGroups = async () => {
    try {
      const res = await fetch("http://localhost:5000/groups", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const groupData = await res.json();
        setGroups(groupData);

        // Fetch balances for each group
        const balancesData = {};
        for (const group of groupData) {
          const resExp = await fetch(`http://localhost:5000/api/group-expenses/group/${group._id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const data = await resExp.json();
          balancesData[group._id] = data.balances || {};
        }
        setBalances(balancesData);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const balance = expenses.reduce(
    (acc, exp) => (exp.type === "Income" ? acc + exp.amount : acc - exp.amount),
    0
  );

  useEffect(() => {
    fetchGroups();
  }, []);

  return (
    <div className="space-y-8">
      <div className="p-4 bg-green-100 border rounded-lg shadow">
        <h2 className="text-xl font-bold">Current Balance</h2>
        <p className={`text-2xl font-semibold ${balance >= 0 ? "text-green-700" : "text-red-600"}`}>
          ₹{balance}
        </p>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Your Expenses & Income</h2>
        {expenses.length > 0 ? (
          <div className="flex space-x-4 overflow-x-auto pb-2">
            {expenses.map((exp) => (
              <div key={exp._id} className="p-4 bg-white shadow rounded-lg border">
                <h3 className="text-lg font-semibold">{exp.category}</h3>
                <p className={`${exp.type === "Income" ? "text-green-600" : "text-red-600"}`}>
                  {exp.type}: ₹{exp.amount}
                </p>
                <p className="text-sm text-gray-500">{new Date(exp.date).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No records found.</p>
        )}
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Your Groups</h2>
        {groups.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groups.map((group) => (
              <div key={group._id} className="p-4 bg-white shadow rounded-lg border">
                <h3 className="text-lg font-semibold">{group.name}</h3>

                {/* Balances instead of members */}
                <ul className="mt-2 space-y-1">
  {group.members
    .filter((m) => (m._id || m) !== user.id)
    .map((m) => {
      const memberId = m._id || m;
      const name = m.name || m.email || m;
      const bal = balances[group._id]?.[memberId] ? -balances[group._id][memberId] : 0;
      return (
        <li key={memberId} className="flex justify-between">
          <span>{name}</span>
          <span className={bal > 0 ? "text-green-500" : "text-red-500"}>
            {bal > 0
              ? ` owes you ₹${bal.toFixed(2)}`
              : `You owe ₹${Math.abs(bal).toFixed(2)}`}
          </span>
        </li>
      );
    })}
</ul>

              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">You are not part of any groups yet.</p>
        )}
      </div>
    </div>
  );
}
